import React from 'react'
import Footer from '../components/Footer'
import Navbar from '../components/Navbar'

const Feedback = () => {
    return (
        <>
            <Navbar />
            <h1>hello this Feedback</h1>
            <Footer />
        </>

    )
}

export default Feedback